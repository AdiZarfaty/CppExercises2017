#pragma once
class SolutionFoundChecker {
public:
	virtual bool isSolutionFound() = 0;
};