//
// Created by Tomer Amir on 31/01/2018.
//

#ifndef EX4_EX4HEADERS_H
#define EX4_EX4HEADERS_H

#include <list>
#include <vector>
#include <iostream>
#include "Puzzle2dPiece.h"
#include "Puzzle3dPiece.h"

#endif //EX4_EX4HEADERS_H
